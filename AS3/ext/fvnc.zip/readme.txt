These ext library entries are for: Desktop Objects - Touch enabled VNC client.

Christian Moore - http://nuiman.com | http://nuigroup.com

Original Client - http://osflash.org/fvnc


Simple put these files into your "ext" directory it should look like;

ext/org/
ext/fvnc/
ext/darronschall/



Then run src/VNC.fla


